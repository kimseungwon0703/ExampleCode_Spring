package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.question.QuestionRepo;
import com.example.demo.question.questionEntity;
import com.example.demo.question.questionService;

//책에서 QuestionController로 수정함 2장 07
@RequestMapping("/question")
@Controller
public class MyController {
	
	@Autowired
	private final QuestionRepo QueRepo;
	
	@Autowired
	private final questionService QueSer;
	
	
	//생성자 초기화 - 문서참고(템플릿에 질문 데이터 전달히가 - Model 활용)
	public MyController(QuestionRepo QueRepo, questionService queSer) {
        this.QueRepo = QueRepo;
		this.QueSer = queSer;
    }
	
	//localhost:8080으로 접속해도 바로 뜰 수 있게 변경
	@GetMapping("/")
	public String root() {
		return "redirect:/question/list";
	}
	
    @GetMapping("/list")
//    @ResponseBody
    public String list(Model model, @RequestParam(value="page", defaultValue="0") int page) {
    	//페이징 기능 questionService 참고
    	Page<questionEntity> paging = this.QueSer.getList(page);
    	model.addAttribute("paging", paging);
    	
    	List<questionEntity> questionList = this.QueSer.getList();
    	//model객체에 questionList라는 이름으로 저장한다.
    	model.addAttribute("questionList", questionList);
        return "question_list";
    }
    
    @GetMapping(value = "/detail/{id}")
    public String Detail(Model model, @PathVariable("id") Integer id) {
    	questionEntity question = this.QueSer.getQuestion(id);
        model.addAttribute("question", question);
    	return "question_detail";
    }
    
    @GetMapping("/create")
    public String questionCreate() {
    	return"question_form";
    }
    
    @PostMapping("/create")
    public String questionCreate(@RequestParam(value="subject") String subject, @RequestParam(value="content") String content){
    	this.QueSer.create(subject, content);
    	return "redirect:/question/list";
    }
}
