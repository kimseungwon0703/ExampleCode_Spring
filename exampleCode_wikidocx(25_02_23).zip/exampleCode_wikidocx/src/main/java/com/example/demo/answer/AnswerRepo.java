package com.example.demo.answer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepo extends JpaRepository<answerEntity, Integer>{

}
