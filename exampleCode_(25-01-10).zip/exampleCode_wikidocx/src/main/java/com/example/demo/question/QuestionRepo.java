package com.example.demo.question;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestionRepo extends JpaRepository<questionEntity, Integer> {

	//findBySubject
	questionEntity findBySubject(String subjcet);
	//findBySubjectAndContent
	questionEntity findBySubjectAndContent(String subject, String content);
	//findBySubjectLike메서드
	List<questionEntity> findBySubjectLike(String subject);
}
