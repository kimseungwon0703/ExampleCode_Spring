package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.question.QuestionRepo;
import com.example.demo.question.questionEntity;

//책에서 QuestionController로 수정함 2장 07
@Controller
public class MyController {
	
	@Autowired
	private final QuestionRepo QueRepo;
	
	//생성자 초기화 - 문서참고(템플릿에 질문 데이터 전달히가 - Model 활용)
	public MyController(QuestionRepo QueRepo) {
        this.QueRepo = QueRepo;
    }
	
	//localhost:8080으로 접속해도 바로 뜰 수 있게 변경
	@GetMapping("/")
	public String root() {
		return "redirect:/question/list";
	}
	
    @GetMapping("/question/list")
//    @ResponseBody
    public String list(Model model) {
//    	System.out.println("Testing text");
    	//findAll()메서드로 질문 목록의 데이터를 가져온다.
    	List<questionEntity> questionList = this.QueRepo.findAll();
    	//model객체에 questionList라는 이름으로 저장한다.
    	model.addAttribute("questionList", questionList);
        return "question_list";
    }
}
