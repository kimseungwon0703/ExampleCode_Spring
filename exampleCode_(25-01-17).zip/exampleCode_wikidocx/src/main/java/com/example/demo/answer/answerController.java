package com.example.demo.answer;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.question.QuestionRepo;
import com.example.demo.question.questionEntity;
import com.example.demo.question.questionService;

@RequestMapping("/answer")
@Controller
public class answerController {

    private final questionService QueSer;
    
    private final answerService AnsSer;
    
    public answerController(questionService QueSer, answerService AnsSer) {
		this.QueSer = QueSer;
		this.AnsSer = AnsSer;
    }

    @PostMapping("/create/{id}")
    public String createAnswer(Model model, @PathVariable("id") Integer id, @RequestParam(value="content") String content) {
        questionEntity question = this.QueSer.getQuestion(id);
        this.AnsSer.create(question, content);
        return String.format("redirect:/question/detail/%s", id);
    }
}