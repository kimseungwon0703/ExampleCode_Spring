package com.example.demo.question;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.DataNotFoundException;

@Service
public class questionService {
	
	private final QuestionRepo QueRepo;
	
	public questionService(QuestionRepo QueRepo) {
        this.QueRepo = QueRepo;
    }
	
	public List<questionEntity> getList(){
		return this.QueRepo.findAll();
	}
	
	public questionEntity getQuestion(Integer id) {  
        Optional<questionEntity> question = this.QueRepo.findById(id);
        if (question.isPresent()) {
            return question.get();
        } else {
            throw new DataNotFoundException("question not found");
        }
    }
}
